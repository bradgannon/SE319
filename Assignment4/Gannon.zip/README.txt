Running Tic-Tac-Toe

1) Navigate to Gannon.zip -> TicTacToe -> src -> game
2) Open the TicTacToe.java file in Eclipse
3) Run the program by pressing the green 'play' button at the top of the screen
4) The GUI will come up, interact with it accordingly
5) If you press 'No' to play again, repeat Step 2 to re-run GUI