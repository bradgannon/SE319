package game;

/**
 * TicTacToe game using JavaFX and utilizing CSS for design components.
 * @author Brad Gannon
 * @date 3/7/2019
 */

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.*;
import javafx.beans.value.*;
import javafx.event.*;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.*;

/**
 * This class is the basis to call methods to create base stage for game, sets starting player and icon
 * @author Brad Gannon
 * @param Stage stage, the stage on which scene will run
 *
 */
public class TicTacToe extends Application {
	@Override
	public void start(Stage stage) throws Exception {
		GameSet gameManager = new GameSet();

		Scene scene = gameManager.getGameScene();
		scene.getStylesheets().add(getResource("design.css")); // See CSS file in src folder

		stage.setTitle("SE 319 Tic-Tac-Toe");
		stage.getIcons().add(SquareSkin.xImg); // 'X' will be first player
		stage.setScene(scene);
		stage.show();
	}

	private String getResource(String resourceName) { // Converts "design.css" to import CSS
		return getClass().getResource(resourceName).toExternalForm();
	}

	public static void main(String[] args) {
		Application.launch(TicTacToe.class); // Launches game
	}
}

/**
 * This class is basic game methods, which are starting new game, quitting game, getting the game, and getting scene
 * @author Brad Gannon
 *
 */
class GameSet {
	private Scene gameScene;
	private Game game;

	GameSet() {
		newGame();
	}

	public void newGame() {
		game = new Game(this);

		if (gameScene == null) {
			gameScene = new Scene(game.getSkin()); // Creates new scene if not one
		} else {
			gameScene.setRoot(game.getSkin());
		}
	}

	public void quit() {
		gameScene.getWindow().hide(); // closes window
	}

	public Game getGame() {
		return game;
	}

	public Scene getGameScene() {
		return gameScene;
	}
}

/**
 * This class is the base game controls for Tic-Tac-Toe.
 * It has the play again button, exit button, and appropriate actions for each
 * @author Brad Gannon
 *
 */
class GameControls extends HBox {
	
	GameControls(final GameSet gameManager, final Game game) {
		getStyleClass().add("game-controls");

		visibleProperty().bind(game.gameOverProperty());

		Label playAgainLabel = new Label("Play Again?");
		playAgainLabel.getStyleClass().add("info");

		Button playAgainButton = new Button("Yes"); // Restart game
		playAgainButton.getStyleClass().add("play-again");
		playAgainButton.setDefaultButton(true);
		playAgainButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				gameManager.newGame(); // Resets game
			}
		});

		Button exitButton = new Button("No");
		playAgainButton.getStyleClass().add("exit");
		exitButton.setCancelButton(true);
		exitButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				gameManager.quit(); // Closes window
			}
		});

		getChildren().setAll(playAgainLabel, playAgainButton, exitButton);
	}
}

/**
 * This class has some more details, such as displaying who the current player is.
 * @author Brad Gannon
 *
 */
class StatusIndicator extends HBox {
	private final ImageView img = new ImageView();
	private final Label lab = new Label("Current Player: ");

	StatusIndicator(Game game) {
		getStyleClass().add("status-indicator");

		bindIndicatorFieldsToGame(game);

		img.setFitHeight(30);
		img.setPreserveRatio(true);

		lab.getStyleClass().add("info");

		getChildren().addAll(lab, img);
	}

	/**
	 * This method essentially displays the appropriate icon for the turn, and then switches to the next player.
	 * This is also taking care of displaying the winner or draw
	 * @param game The current Game object being used
	 */
	private void bindIndicatorFieldsToGame(Game game) {
		img.imageProperty()
				.bind(Bindings.when(game.currentPlayerProperty().isEqualTo(Square.State.O))
						.then(SquareSkin.oImg)
						.otherwise(Bindings.when(game.currentPlayerProperty().isEqualTo(Square.State.X))
								.then(SquareSkin.xImg).otherwise((Image) null)));

		lab.textProperty()
				.bind(Bindings.when(game.gameOverProperty().not()).then("Current Player: ")
						.otherwise(Bindings.when(game.winnerProperty().isEqualTo(Square.State.EMPTY)).then("Draw")
								.otherwise("Winning Player: ")));
	}
}

/**
 * Class to organize all aspects of the game. It contains the skin, board, and winning strategy.
 * Checks if game is over, sets new player, and has a switch-case statement to determine appropriate turn.
 * @author Brad Gannon
 *
 */
class Game {
	private GameSkin skin;
	private Board board = new Board(this);
	private WinningStrategy winningStrategy = new WinningStrategy(board);

	private ReadOnlyObjectWrapper<Square.State> currentPlayer = new ReadOnlyObjectWrapper<>(Square.State.X);

	public ReadOnlyObjectProperty<Square.State> currentPlayerProperty() {
		return currentPlayer.getReadOnlyProperty();
	}

	public Square.State getCurrentPlayer() {
		return currentPlayer.get();
	}

	private ReadOnlyObjectWrapper<Square.State> winner = new ReadOnlyObjectWrapper<>(Square.State.EMPTY);

	public ReadOnlyObjectProperty<Square.State> winnerProperty() {
		return winner.getReadOnlyProperty();
	}

	private ReadOnlyBooleanWrapper drawn = new ReadOnlyBooleanWrapper(false);

	public ReadOnlyBooleanProperty drawnProperty() {
		return drawn.getReadOnlyProperty();
	}

	public boolean isDrawn() {
		return drawn.get();
	}

	private ReadOnlyBooleanWrapper gameOver = new ReadOnlyBooleanWrapper(false);

	public ReadOnlyBooleanProperty gameOverProperty() {
		return gameOver.getReadOnlyProperty();
	}

	public boolean isGameOver() {
		return gameOver.get();
	}

	public Game(GameSet gameManager) {
		gameOver.bind(winnerProperty().isNotEqualTo(Square.State.EMPTY).or(drawnProperty()));

		skin = new GameSkin(gameManager, this);
	}

	public Board getBoard() {
		return board;
	}

	public void nextTurn() {
		if (isGameOver())
			return;

		switch (currentPlayer.get()) {
		case EMPTY:
		case O:
			currentPlayer.set(Square.State.X);
			break;
		case X:
			currentPlayer.set(Square.State.O);
			break;
		}
	}

	private void checkForWinner() {
		winner.set(winningStrategy.getWinner());
		drawn.set(winningStrategy.isDrawn());

		if (isDrawn()) {
			currentPlayer.set(Square.State.EMPTY);
		}
	}

	public void boardUpdated() {
		checkForWinner();
	}

	public Parent getSkin() {
		return skin;
	}
}

/**
 * Simple class to organize visual components of board skin.
 * @author Brad Gannon
 *
 */
class GameSkin extends VBox {
	GameSkin(GameSet gameManager, Game game) {
		getChildren().addAll(game.getBoard().getSkin(), new StatusIndicator(game), new GameControls(gameManager, game));
	}
}

/**
 * This class utilizes a simple HashMap and for-loops to determine if winner.
 * @author Brad Gannon
 *
 */
class WinningStrategy {
	private final Board board;

	private static final int O_WON = 3;
	private static final int X_WON = 30;

	private static final Map<Square.State, Integer> values = new HashMap<>();
	static {
		values.put(Square.State.EMPTY, 0); // Can never be more than 0
		values.put(Square.State.O, 1); // 1 + 1 + 1 = 3 (winner)
		values.put(Square.State.X, 10); // 10 + 10 + 10 = 30 (winner)
	}

	public WinningStrategy(Board board) {
		this.board = board;
	}

	public Square.State getWinner() { // Following for-loops are simply adding up values
		for (int i = 0; i < 3; i++) {
			int score = 0;
			for (int j = 0; j < 3; j++) {
				score += valueOf(i, j);
			}
			if (isWinning(score)) {
				return winner(score);
			}
		}

		for (int i = 0; i < 3; i++) {
			int score = 0;
			for (int j = 0; j < 3; j++) {
				score += valueOf(j, i);
			}
			if (isWinning(score)) {
				return winner(score);
			}
		}

		int score = 0;
		score += valueOf(0, 0);
		score += valueOf(1, 1);
		score += valueOf(2, 2);
		if (isWinning(score)) {
			return winner(score);
		}

		score = 0;
		score += valueOf(2, 0);
		score += valueOf(1, 1);
		score += valueOf(0, 2);
		if (isWinning(score)) {
			return winner(score);
		}

		return Square.State.EMPTY;
	}

	public boolean isDrawn() {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (board.getSquare(i, j).getState() == Square.State.EMPTY) {
					return false;
				}
			}
		}

		return getWinner() == Square.State.EMPTY;
	}

	private Integer valueOf(int i, int j) {
		return values.get(board.getSquare(i, j).getState());
	}

	private boolean isWinning(int score) {
		return score == O_WON || score == X_WON;
	}

	private Square.State winner(int score) {
		if (score == O_WON)
			return Square.State.O;
		if (score == X_WON)
			return Square.State.X;

		return Square.State.EMPTY;
	}
}

/**
 * Class to set up the actual grid.
 * @author Brad Gannon
 *
 */
class Board {
	private final BoardSkin skin;

	private final Square[][] squares = new Square[3][3];

	public Board(Game game) {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				squares[i][j] = new Square(game);
			}
		}

		skin = new BoardSkin(this);
	}

	public Square getSquare(int i, int j) {
		return squares[i][j];
	}

	public Node getSkin() {
		return skin;
	}
}

/**
 * Applies skin to each square in the grid.
 * @author Brad Gannon
 *
 */
class BoardSkin extends GridPane {
	BoardSkin(Board board) {
		getStyleClass().add("board");

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				add(board.getSquare(i, j).getSkin(), i, j);
			}
		}
	}
}

/**
 * Contains enum for the states of game. Checks if square has been pressed
 * 
 * @author Brad Gannon
 *
 */
class Square {
	enum State {
		EMPTY, O, X
	}

	private final SquareSkin skin;

	private ReadOnlyObjectWrapper<State> state = new ReadOnlyObjectWrapper<>(State.EMPTY);

	public ReadOnlyObjectProperty<State> stateProperty() {
		return state.getReadOnlyProperty();
	}

	public State getState() {
		return state.get();
	}

	private final Game game;

	public Square(Game game) {
		this.game = game;

		skin = new SquareSkin(this);
	}

	public void pressed() {
		if (!game.isGameOver() && state.get() == State.EMPTY) {
			state.set(game.getCurrentPlayer());
			game.boardUpdated();
			game.nextTurn();
		}
	}

	public Node getSkin() {
		return skin;
	}
}

/**
 * Applies images to the squares where necessary. Creates ImageViewer that is then replaced with image based on switch-case statement.
 * Sets the size of images in switch-case statement as well.
 * @author Brad Gannon
 *
 */
class SquareSkin extends StackPane {
	static final Image oImg = new Image(
			"file:o.jpg");
	static final Image xImg = new Image(
			"file:x.jpg");

	private final ImageView imageView = new ImageView();

	SquareSkin(final Square square) {
    getStyleClass().add("square");

    imageView.setMouseTransparent(true);
    
    getChildren().setAll(imageView);
    setPrefSize(150, 150);

    setOnMousePressed(new EventHandler<MouseEvent>() {
      @Override public void handle(MouseEvent mouseEvent) {
        square.pressed();
      }
    });

    square.stateProperty().addListener(new ChangeListener<Square.State>() {
      @Override public void changed(ObservableValue<? extends Square.State> observableValue, Square.State oldState, Square.State state) {
        switch (state) {
          case EMPTY:  
        	  imageView.setImage(null);        
        	  break;
          case O: 
        	  imageView.setImage(oImg); 
        	  imageView.setFitHeight(125);
        	  imageView.setFitWidth(125);
        	  break;
          case X:  
        	  imageView.setImage(xImg); 
        	  imageView.setFitHeight(125);
        	  imageView.setFitWidth(125);
        	  break;
        }
      }
    });
  }
}