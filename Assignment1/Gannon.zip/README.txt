Brad Gannon
Assignment 1 README
Compiling and Running Program
Language Used: Java
Steps for Compiling and Running:
First, open Server.java and Client.java in Eclipse.  Next, in the Package Explorer tab, expand the ChatRoom and src folders to get to the files.  Right click on Server, then go to Run As and then finally click Run As Java Application.  The Server.java file needs to be ran before Client.java.  Finally, run Client.java in the same manner as Server.java and follow the prompts in the console at the bottom of the screen.  Many clients can be ran during a session, each one just has to be ran as a Java application following the previously described directions.
