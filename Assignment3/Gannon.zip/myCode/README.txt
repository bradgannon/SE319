Compile and Run Part 1 (snake.html, snake.js)

Run the snake.html file in a web browser (Chrome, Internet Explorer, etc.) and press the Start button. The program should then run appropriately.
------------------------------

Compile and Run Part 2 (hw3.js)

Open a command-line console (Cygwin, Command Prompt, Terminal, etc.) and navigate to the appropriate folder that hw3.js is in. It may be necessary to first enter the command
"npm install readline-sync". Once that is complete, enter the command "node hw3.js". This should run the program, and then follow the prompts on the screen to enter numbers.
After this, the appropriate output of the program should be shown on the console window.\
------------------------------